#!/usr/bin/python

# exp floor factorial sqrt pow cos
import math

test_int=1
print (math.exp(test_int))

num=2.3

print('The ceil  of 2.3 is %d '%(math.ceil(num)))
print('The floor of 2.3 is %d '%(math.floor(num)))
print('The factorial of 5 is %d '%(math.factorial(5)))
print('The square root of 16 is %d '%(math.sqrt(16)))
a=math.pi/6
print('The cosine of pi/6  is %f '%(math.cos(a)))
print('The pow of 2,5 is %d '%(math.pow(2,5)))
