#!/usr/bin/python
List=[]
print(List)

List=[10,20,30]

print(List)

List=["Chetana","College","of","BCA"]

print(List)

print(List[0])
print(List[1])
print(List[2])
print(List[3])

print(len(List))

score=[[10,20,30],[50,60,70]]

print(score[0][0])
print(score[0][1])
print(score[0][2])
print(score[1][0])
print(score[1][1])
print(score[1][2])
