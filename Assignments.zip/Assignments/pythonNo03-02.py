#!/usr/bin/python

#tuples

tuple1=()
print (tuple1)

tuple1=('chetana','college','of','eng')

print (tuple1)

List=[1,2,3,4,5]
tuple1 = tuple(List)

print(tuple1)

tuple1 = tuple('Chetana')
print(tuple1)

