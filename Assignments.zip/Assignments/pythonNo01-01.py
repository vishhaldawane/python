#!/usr/bin/python

def squaresum(n):
  sm=0
  for i in range(1, n+1) :
    sm = sm + (i * i)

  return sm

n = 4
print(squaresum(n))

print( ' -------' )

def squareSum(n):
   sum =0
   for i in range(1,n+1) :
     sum = sum + ( i * i)

   return sum

N=10
print ( squareSum(N))













def squareTheSum(n) :
  sum=0
  for i in range(1,n+1):
     sum = sum + ( i*i)
  return sum;

print(squareTheSum(5))

def squr(n):
  sum=0
  for i in range(1,n+1):
     sm = sum+ ( i * i)
  return sm;

print(squr(4))
