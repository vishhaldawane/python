#!/usr/bin/python

# Import Module
from tkinter import *

# create root window
root = Tk()

# root window title and dimension
root.title("Welcome to GeekForGeeks")
# Set geometry (widthxheight)
root.geometry('350x200')

# all widgets will be here
# Execute Tkinter
root.mainloop()

